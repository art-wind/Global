package Runnable;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import javax.net.ssl.SSLEngineResult.Status;

import org.json.*;

import utils.FetchThread;
import utils.ThreadStatus;

public class Fetch {
	static String API_KEY = "AIzaSyDsL6qS7fjPLTClrVbckuGY5Cv9ZhpJwhE";
	
	//Modify the finishedNumber when 50,000 response has been reached
	static int finishedNumber = 9;
	//16326
	static int startLine = 10040;
	static ThreadStatus status;
	static int threadMax = 25;
	public static void main(String[] args) throws MalformedURLException, IOException, InterruptedException {
		String radius = "50";
		
		File placesFile = new File("data/places/"+finishedNumber+".txt");
		Scanner scanner = new Scanner(placesFile);
		status = new ThreadStatus();
		
		int lineNum = 0;
		while(scanner.hasNext()){
			if(lineNum<startLine){
				scanner.nextLine();
				lineNum++;
				continue;
			}
			while(!status.goodToGo(threadMax)){
				Thread.sleep(1000);
				System.out.println("Sleep");
			}
			status.addThread();
			String line = scanner.nextLine();
			FetchThread thread = new FetchThread(finishedNumber, line, API_KEY, radius,lineNum,status);
			thread.start();
			lineNum++;
		}
	}

}
