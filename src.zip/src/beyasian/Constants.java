package beyasian;

public class Constants {
	public static final int COMMON_PLACE_ALPHA = 1;
	public static final int COMMON_PLACE_BETA = 10;
	
	public static final double INTERVAL_RATE_ALPHA = 0.3;
	public static final double INTERVAL_RATE_BETA= 0.6;
	
}
